import React, { useState } from 'react';
import { BookOpen, Users, Camera, Sparkles, Moon, Globe, Crown, Star } from 'lucide-react';

interface User {
  type: 'child' | 'educator';
  name: string;
}

function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'login' | 'dashboard' | 'avatar' | 'dreams'>('landing');
  const [user, setUser] = useState<User | null>(null);

  const historicalFigures = [
    { name: 'Emperor Akbar', era: 'Mughal Dynasty', image: '👑', description: 'The Great Mughal Emperor who promoted unity and tolerance' },
    { name: 'Birbal', era: 'Mughal Court', image: '🎭', description: 'Witty courtier known for his clever solutions' },
    { name: 'Tenali Rama', era: 'Vijayanagara', image: '🤹', description: 'Legendary poet and advisor famous for his humor' },
    { name: 'Rani Lakshmibai', era: 'Maratha Empire', image: '⚔️', description: 'Brave warrior queen who fought for independence' }
  ];

  const dreamSymbols = [
    { symbol: '🐘', meaning: 'Elephant - Symbol of wisdom, strength, and good fortune ahead' },
    { symbol: '🦚', meaning: 'Peacock - Represents beauty, grace, and spiritual awakening' },
    { symbol: '🌺', meaning: 'Lotus - Signifies purity, enlightenment, and new beginnings' },
    { symbol: '🐍', meaning: 'Serpent - Indicates transformation and healing energy' }
  ];

  const LandingPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-800 to-orange-600">
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <div className="flex justify-center items-center mb-6">
            <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mr-4 animate-pulse">
              <Crown className="w-8 h-8 text-purple-800" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white">
              Heritage Tales
            </h1>
          </div>
          <p className="text-xl md:text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
            Step into history and reimagine culture through AI-powered storytelling, 3D adventures, and interactive experiences with legendary figures
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300 transform hover:scale-105">
            <div className="flex items-center mb-6">
              <BookOpen className="w-8 h-8 text-yellow-400 mr-4" />
              <h3 className="text-2xl font-bold text-white">For Young Explorers</h3>
            </div>
            <ul className="text-blue-100 space-y-3 text-lg">
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-yellow-400" />Chat with AI avatars of historical figures</li>
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-yellow-400" />Upload photos and join 3D stories</li>
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-yellow-400" />Gamified learning with rewards</li>
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-yellow-400" />AR experiences and dream interpretation</li>
            </ul>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300 transform hover:scale-105">
            <div className="flex items-center mb-6">
              <Users className="w-8 h-8 text-orange-400 mr-4" />
              <h3 className="text-2xl font-bold text-white">For Educators & Creators</h3>
            </div>
            <ul className="text-blue-100 space-y-3 text-lg">
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-orange-400" />Create and request cultural content</li>
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-orange-400" />Generate 3D educational videos</li>
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-orange-400" />Access diverse cultural traditions</li>
              <li className="flex items-center"><Star className="w-5 h-5 mr-3 text-orange-400" />Multilingual content support</li>
            </ul>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => setCurrentPage('login')}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold py-4 px-8 rounded-full text-xl hover:from-yellow-500 hover:to-orange-600 transform hover:scale-105 transition-all duration-300 shadow-2xl"
          >
            Begin Your Cultural Journey
          </button>
        </div>
      </div>
    </div>
  );

  const LoginPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-800 to-teal-600 flex items-center justify-center px-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-12 border border-white/20 max-w-md w-full">
        <h2 className="text-3xl font-bold text-white text-center mb-8">Choose Your Path</h2>
        
        <div className="space-y-6">
          <button
            onClick={() => {
              setUser({ type: 'child', name: 'Young Explorer' });
              setCurrentPage('dashboard');
            }}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white font-bold py-4 px-6 rounded-2xl hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 flex items-center justify-center"
          >
            <BookOpen className="w-6 h-6 mr-3" />
            Child / Student
          </button>
          
          <button
            onClick={() => {
              setUser({ type: 'educator', name: 'Cultural Educator' });
              setCurrentPage('dashboard');
            }}
            className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white font-bold py-4 px-6 rounded-2xl hover:from-orange-600 hover:to-red-700 transform hover:scale-105 transition-all duration-300 flex items-center justify-center"
          >
            <Users className="w-6 h-6 mr-3" />
            Educator / Creator
          </button>
        </div>

        <button
          onClick={() => setCurrentPage('landing')}
          className="w-full mt-6 text-white/70 hover:text-white transition-colors duration-300"
        >
          ← Back to Home
        </button>
      </div>
    </div>
  );

  const Dashboard = () => (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-pink-700">
      <div className="container mx-auto px-6 py-12">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-bold text-white">Welcome, {user?.name}!</h1>
          <button
            onClick={() => setCurrentPage('landing')}
            className="bg-white/20 text-white px-6 py-2 rounded-full hover:bg-white/30 transition-colors duration-300"
          >
            Logout
          </button>
        </div>

        {user?.type === 'child' ? (
          <div className="space-y-12">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-br from-blue-600 to-purple-700 rounded-3xl p-8 border border-white/20 hover:scale-105 transition-transform duration-300">
                <div className="flex items-center mb-6">
                  <BookOpen className="w-10 h-10 text-yellow-400 mr-4" />
                  <h3 className="text-2xl font-bold text-white">Real History</h3>
                </div>
                <p className="text-blue-100 mb-6 text-lg">Discover authentic stories and interact with historical figures in their true settings</p>
                <button
                  onClick={() => setCurrentPage('avatar')}
                  className="bg-yellow-400 text-purple-800 font-bold py-3 px-6 rounded-full hover:bg-yellow-500 transition-colors duration-300"
                >
                  Meet Historical Figures
                </button>
              </div>

              <div className="bg-gradient-to-br from-pink-600 to-red-700 rounded-3xl p-8 border border-white/20 hover:scale-105 transition-transform duration-300">
                <div className="flex items-center mb-6">
                  <Sparkles className="w-10 h-10 text-yellow-400 mr-4" />
                  <h3 className="text-2xl font-bold text-white">Creative Reimagination</h3>
                </div>
                <p className="text-red-100 mb-6 text-lg">Reshape stories and imagine how history would unfold in today's world</p>
                <button className="bg-yellow-400 text-red-800 font-bold py-3 px-6 rounded-full hover:bg-yellow-500 transition-colors duration-300">
                  Create New Stories
                </button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300">
                <Camera className="w-8 h-8 text-green-400 mb-4" />
                <h4 className="text-xl font-bold text-white mb-2">3D Photo Stories</h4>
                <p className="text-white/80">Upload your photo and see yourself in historical adventures</p>
              </div>

              <div 
                className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 cursor-pointer"
                onClick={() => setCurrentPage('dreams')}
              >
                <Moon className="w-8 h-8 text-purple-400 mb-4" />
                <h4 className="text-xl font-bold text-white mb-2">Dream Predictor</h4>
                <p className="text-white/80">Discover meanings of your dreams through ancient wisdom</p>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300">
                <Globe className="w-8 h-8 text-blue-400 mb-4" />
                <h4 className="text-xl font-bold text-white mb-2">Cultural Hub</h4>
                <p className="text-white/80">Explore diverse traditions and languages from around the world</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-br from-teal-600 to-blue-700 rounded-3xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4">Content Creation Studio</h3>
                <p className="text-teal-100 mb-6">Generate 3D videos and interactive cultural content</p>
                <button className="bg-yellow-400 text-blue-800 font-bold py-3 px-6 rounded-full">Create Content</button>
              </div>

              <div className="bg-gradient-to-br from-orange-600 to-red-700 rounded-3xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4">Analytics & Insights</h3>
                <p className="text-orange-100 mb-6">Track engagement and educational impact</p>
                <button className="bg-yellow-400 text-red-800 font-bold py-3 px-6 rounded-full">View Analytics</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const AvatarPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-800 to-indigo-900">
      <div className="container mx-auto px-6 py-12">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-bold text-white">Meet Historical Figures</h1>
          <button
            onClick={() => setCurrentPage('dashboard')}
            className="bg-white/20 text-white px-6 py-2 rounded-full hover:bg-white/30 transition-colors duration-300"
          >
            ← Back to Dashboard
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {historicalFigures.map((figure, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 transform hover:scale-105">
              <div className="text-center">
                <div className="text-6xl mb-4">{figure.image}</div>
                <h3 className="text-xl font-bold text-white mb-2">{figure.name}</h3>
                <p className="text-purple-200 text-sm mb-2">{figure.era}</p>
                <p className="text-white/80 text-sm mb-4">{figure.description}</p>
                <button className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold py-2 px-4 rounded-full hover:from-yellow-500 hover:to-orange-600 transition-all duration-300">
                  Start Conversation
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 max-w-2xl mx-auto">
          <div className="flex items-center mb-6">
            <div className="text-4xl mr-4">👑</div>
            <div>
              <h3 className="text-2xl font-bold text-white">Emperor Akbar</h3>
              <p className="text-purple-200">Mughal Dynasty • 1556-1605</p>
            </div>
          </div>
          
          <div className="space-y-4 mb-6">
            <div className="bg-blue-600/30 rounded-2xl p-4">
              <p className="text-white">"Welcome, young friend! I am Akbar, Emperor of Hindustan. What would you like to know about building a united empire?"</p>
            </div>
            
            <div className="bg-white/20 rounded-2xl p-4 text-right">
              <p className="text-white">"How did you bring different religions together?"</p>
            </div>
            
            <div className="bg-blue-600/30 rounded-2xl p-4">
              <p className="text-white">"Ah, excellent question! I believed that all religions have wisdom. I created the 'Din-i Ilahi' - a path that respected all faiths..."</p>
            </div>
          </div>
          
          <div className="flex space-x-4">
            <input
              type="text"
              placeholder="Ask Emperor Akbar a question..."
              className="flex-1 bg-white/10 border border-white/20 rounded-full px-6 py-3 text-white placeholder-white/60"
            />
            <button className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-6 py-3 rounded-full hover:from-yellow-500 hover:to-orange-600 transition-all duration-300">
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const DreamPredictorPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-pink-700">
      <div className="container mx-auto px-6 py-12">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-bold text-white">Dream Predictor</h1>
          <button
            onClick={() => setCurrentPage('dashboard')}
            className="bg-white/20 text-white px-6 py-2 rounded-full hover:bg-white/30 transition-colors duration-300"
          >
            ← Back to Dashboard
          </button>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 mb-8">
            <div className="text-center mb-8">
              <Moon className="w-16 h-16 text-purple-400 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-white mb-4">Ancient Dream Wisdom</h2>
              <p className="text-purple-200 text-lg">Discover the meanings behind your dreams through ancient texts and cultural interpretations</p>
            </div>

            <div className="bg-purple-600/30 rounded-2xl p-6 mb-8">
              <h3 className="text-xl font-bold text-white mb-4">Tell us about your dream:</h3>
              <textarea
                className="w-full h-32 bg-white/10 border border-white/20 rounded-xl p-4 text-white placeholder-white/60 resize-none"
                placeholder="I dreamed about flying over a golden palace with peacocks..."
              />
              <button className="mt-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold py-3 px-6 rounded-full hover:from-yellow-500 hover:to-orange-600 transition-all duration-300">
                Interpret My Dream
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {dreamSymbols.map((item, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300">
                <div className="flex items-center mb-4">
                  <span className="text-4xl mr-4">{item.symbol}</span>
                  <div>
                    <h4 className="text-lg font-bold text-white">{item.meaning.split(' - ')[0]}</h4>
                  </div>
                </div>
                <p className="text-white/80">{item.meaning.split(' - ')[1]}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 bg-gradient-to-r from-purple-600/30 to-pink-600/30 rounded-2xl p-6 border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-4">Your Dream Interpretation</h3>
            <div className="bg-white/10 rounded-xl p-6">
              <p className="text-white/90 leading-relaxed">
                🕊️ <strong>Flying</strong> represents freedom and spiritual ascension in ancient texts.<br/>
                🏰 <strong>Golden Palace</strong> symbolizes prosperity and divine blessings approaching.<br/>
                🦚 <strong>Peacocks</strong> indicate beauty, grace, and the unfolding of your creative potential.<br/><br/>
                <em>According to Vedic dream interpretation, this dream suggests a period of spiritual growth and material abundance is coming into your life.</em>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="font-sans">
      {currentPage === 'landing' && <LandingPage />}
      {currentPage === 'login' && <LoginPage />}
      {currentPage === 'dashboard' && <Dashboard />}
      {currentPage === 'avatar' && <AvatarPage />}
      {currentPage === 'dreams' && <DreamPredictorPage />}
    </div>
  );
}

export default App;